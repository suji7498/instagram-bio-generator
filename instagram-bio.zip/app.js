const { useState, useEffect, useRef } = React;

// Keyword data from provided JSON
const keywordData = {
  top10: [
    "instagram bio",
    "instagram bio for girls", 
    "instagram bio for boys",
    "best bio for instagram",
    "cool bio for instagram",
    "attitude instagram bio",
    "instagram vip bio",
    "instagram attitude bio",
    "aesthetic bio for instagram",
    "attitude bio for instagram"
  ],
  others: [
    "instagram bio attitude",
    "instagram bio style",
    "instagram bio ideas",
    "instagram bio for boys stylish font",
    "bio for instagram for boys",
    "classy instagram bio",
    "instagram bio for boys attitude",
    "instagram bio quotes",
    "swag attitude bio for instagram for girl",
    "instagram bio for girls stylish",
    "instagram stylish bio",
    "stylish bio for instagram",
    "cool instagram bio for girls",
    "2 line bio for instagram for boy",
    "bio for instagram for girls attitude",
    "bio for instagram for boy attitude",
    "best bio for instagram for boys",
    "instagram bio captions",
    "bio for instagram girls",
    "bio for instagram for girl in stylish font",
    "instagram bio for girls simple",
    "instagram bio for girls attitude",
    "love bio for instagram",
    "best bio for instagram for girls",
    "impressive instagram bio for boys",
    "cute instagram bios",
    "2 line bio for instagram for girl",
    "short bio for instagram",
    "instagram bio font",
    "sad bio for instagram",
    "instagram bio hindi",
    "instagram bio for boys 2020",
    "english bio for instagram for girl",
    "aesthetic instagram bios",
    "instagram bio for boys stylish",
    "best instagram bio for girl",
    "simple instagram bio",
    "instagram vip bio for boy",
    "bio for instagram for boy attitude 2020",
    "attitude bio for instagram for girl"
  ]
};

// Bio data
const biosData = {
  categories: [
    {
      name: "Love",
      bios: [
        "💖ֆɨʍքʟɛ ֆɨ ʟօʋɛ զʊɛɛռ👑",
        "You + Me = Endless Love ♾️",
        "💕 Living my dream with you",
        "🔐 Locked in love",
        "❤️ Love is life 🖤",
        "😘 My queen: @username",
        "Two hearts, one love story 💑",
        "🌍 My world has just 3 letters: You",
        "🥰 You complete me 🧩",
        "💓 Love vibes only"
      ]
    },
    {
      name: "Attitude",
      bios: [
        "😎 Attitude level: WiFi — always connected",
        "👑 King by birth, lion by mindset",
        "🚫 Zero emotions, 100% focus",
        "✌️ Calm look, deadly thoughts",
        "I don't chase people — I chase dreams 🔥",
        "Too glam to give a damn ✨",
        "Self-made and unstoppable 💪",
        "No crown needed — my vibe says it all 👑",
        "Classy, sassy, & a bit smart-assy 💋",
        "Born original, never meant to fit in 🌟"
      ]
    },
    {
      name: "Funny",
      bios: [
        "Error 404: Bio unavailable 😂",
        "Professional napper 💤",
        "Fries over guys 🍟",
        "Fluent in sarcasm and movie quotes 🎬",
        "Microwave chef extraordinaire 🍲",
        "I'm on a seafood diet. I see food & I eat it 🐟",
        "I need two six-month vacations this year 🏖️",
        "My life's a joke; I'm the punchline 🤡",
        "Operator of the sarcasm machine 🛠️",
        "Catch flights, not feelings ✈️"
      ]
    },
    {
      name: "Travel",
      bios: [
        "✈️ Globe-trotter at heart",
        "Chasing sunsets & passport stamps 🌅",
        "Adventure seeker on a quest 🗺️",
        "🏝️ Beach vibes & high tides",
        "Road tripping to unknown destinations 🚗",
        "Lost & loving it 🌐",
        "Scaling mountains to surfing tides 🏔️🌊",
        "📸 Capturing moments one destination at a time",
        "Minimalist wayfarer 🎒",
        "Sunset collector 🌄"
      ]
    },
    {
      name: "Fitness",
      bios: [
        "🏋️‍♂️ Strong body, stronger mind",
        "Sweat is my superpower 💦",
        "Progress, not perfection 📈",
        "Train like a beast, look like a beauty 🦁",
        "Gym is my therapy session 🔥",
        "Unlock your potential with every rep 🔑",
        "No excuses, just results 💪",
        "Stronger every day 🚀",
        "Chasing gains & good vibes ✨",
        "Turning sweat into strength 🌟"
      ]
    },
    {
      name: "Motivational",
      bios: [
        "Dream big, work harder ✨",
        "Believe in yourself; you're halfway there 🌱",
        "Turning obstacles into opportunities 🔄",
        "Rising above challenges, one day at a time ⬆️",
        "Progress over perfection 🛤️",
        "Be the energy you want to attract ⚡",
        "Success starts with self-belief 💫",
        "Creating a life I love 🏡",
        "Mindset is everything 🧠",
        "Hustle + heart = success ❤️‍🔥"
      ]
    },
    {
      name: "Friendship",
      bios: [
        "Partners in crime since '99 👯",
        "Friends are the family we choose 🌟",
        "Adventure buddies forever ✈️",
        "Pizza lovers unite 🍕",
        "Sharing laughs & inside jokes 😂",
        "Trust, loyalty, love — that's us 💖",
        "Selfie queens 👑",
        "Making memories one hangout at a time 📸",
        "Side by side or miles apart, friends at heart ❤️",
        "Squad goals unlocked 🔓"
      ]
    },
    {
      name: "Business",
      bios: [
        "Building empires, not excuses 🏗️",
        "CEO of my own life 💼",
        "Turning ideas into income 💡💰",
        "Helping brands grow 🌱",
        "Results speak louder than words 📈",
        "Your trusted digital partner 🤝",
        "Making money moves daily 💵",
        "Quality over quantity, always ✔️",
        "Creating value, delivering excellence ⭐",
        "Let's collaborate — DM me 📩"
      ]
    },
    {
      name: "Aesthetic",
      bios: [
        "Chasing sunsets and making memories 🌅",
        "Quiet soul, loud thoughts 🌙",
        "Dreaming with my eyes open ✨",
        "Chaos, but make it cute 🌸",
        "Here for the vibes 🌈",
        "Stay soft, it confuses them 🌷",
        "Universe in my veins, stardust in my soul ✨",
        "Life in pastel tones 🎨",
        "Offline is the new luxury 📴",
        "Golden hour in a person 🌞"
      ]
    },
    {
      name: "Quotes",
      bios: [
        '"Be yourself; everyone else is already taken." – Oscar Wilde',
        '"Do what you love, love what you do."',
        '"The best way out is always through."',
        '"Not all those who wander are lost." – Tolkien',
        '"Happiness depends upon ourselves." – Aristotle',
        '"Create your own sunshine."',
        '"Dream big and dare to fail." – Norman Vaughan',
        '"What you think, you become." – Buddha',
        '"Life is a daring adventure or nothing at all." – Helen Keller',
        '"Believe you can and you\'re halfway there." – Roosevelt'
      ]
    }
  ]
};

// Theme Toggle Component
const ThemeToggle = ({ isDark, onToggle }) => {
  return (
    <button className="theme-toggle" onClick={onToggle} aria-label="Toggle theme">
      {isDark ? (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="12" cy="12" r="5"></circle>
          <line x1="12" y1="1" x2="12" y2="3"></line>
          <line x1="12" y1="21" x2="12" y2="23"></line>
          <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
          <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
          <line x1="1" y1="12" x2="3" y2="12"></line>
          <line x1="21" y1="12" x2="23" y2="12"></line>
          <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
          <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
        </svg>
      ) : (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
        </svg>
      )}
    </button>
  );
};

// Keywords Section Component
const KeywordsSection = ({ onKeywordClick, activeKeyword }) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleDropdownItemClick = (keyword) => {
    onKeywordClick(keyword);
    setDropdownOpen(false);
  };

  return (
    <div className="keywords-section">
      <div className="keywords-header">
        <p className="keywords-text">Popular Keywords</p>
        <div className="more-keywords-dropdown" ref={dropdownRef}>
          <button 
            className="dropdown-btn"
            onClick={() => setDropdownOpen(!dropdownOpen)}
            aria-label="More keywords"
          >
            More Keywords
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </button>
          <div className={`dropdown-menu ${dropdownOpen ? '' : 'hidden'}`}>
            {keywordData.others.map((keyword, index) => (
              <button
                key={index}
                className="dropdown-item"
                onClick={() => handleDropdownItemClick(keyword)}
              >
                {keyword}
              </button>
            ))}
          </div>
        </div>
      </div>
      <div className="keyword-chips">
        {keywordData.top10.map((keyword, index) => (
          <button
            key={index}
            className={`keyword-chip ${activeKeyword === keyword ? 'active' : ''}`}
            onClick={() => onKeywordClick(keyword)}
          >
            {keyword}
          </button>
        ))}
      </div>
    </div>
  );
};

// Bio Card Component
const BioCard = ({ bio, onCopy }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(bio);
      setCopied(true);
      onCopy();
      setTimeout(() => setCopied(false), 1500);
    } catch (err) {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = bio;
      textArea.style.position = 'fixed';
      textArea.style.left = '-9999px';
      document.body.appendChild(textArea);
      textArea.select();
      try {
        document.execCommand('copy');
        setCopied(true);
        onCopy();
        setTimeout(() => setCopied(false), 1500);
      } catch (fallbackErr) {
        console.error('Copy failed', fallbackErr);
      }
      document.body.removeChild(textArea);
    }
  };

  return (
    <div className="bio-card">
      <p className="bio-text">{bio}</p>
      <button className="copy-btn" onClick={handleCopy} aria-label={`Copy bio: ${bio}`}>
        {copied ? (
          <>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="20 6 9 17 4 12"></polyline>
            </svg>
            <span>Copied!</span>
          </>
        ) : (
          <>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
            </svg>
            <span>Copy</span>
          </>
        )}
      </button>
    </div>
  );
};

// Toast Component
const Toast = ({ show }) => {
  return (
    <div className={`toast ${show ? 'show' : 'hidden'}`}>
      <span className="toast-text">Copied to clipboard!</span>
    </div>
  );
};

// Main App Component
const App = () => {
  const [isDarkTheme, setIsDarkTheme] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeKeyword, setActiveKeyword] = useState('');
  const [showToast, setShowToast] = useState(false);

  // Apply theme class to body
  useEffect(() => {
    document.body.className = isDarkTheme ? 'dark-theme' : 'light-theme';
  }, [isDarkTheme]);

  const handleThemeToggle = () => {
    setIsDarkTheme(!isDarkTheme);
  };

  const handleKeywordClick = (keyword) => {
    setSearchTerm(keyword);
    setActiveKeyword(keyword);
    // Scroll to categories section
    setTimeout(() => {
      const categoriesSection = document.querySelector('.main-content');
      if (categoriesSection) {
        categoriesSection.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  const handleSearchChange = (e) => {
    const value = e.target.value;
    setSearchTerm(value);
    setActiveKeyword(''); // Clear active keyword when manually typing
  };

  const handleCopy = () => {
    setShowToast(true);
    setTimeout(() => setShowToast(false), 1800);
  };

  // Filter bios based on search term
  const getFilteredCategories = () => {
    // If no search term, show all categories
    if (!searchTerm.trim()) {
      return biosData.categories;
    }
    
    const searchLower = searchTerm.toLowerCase().trim();
    return biosData.categories.map(category => ({
      ...category,
      bios: category.bios.filter(bio => 
        bio.toLowerCase().includes(searchLower) ||
        category.name.toLowerCase().includes(searchLower)
      )
    })).filter(category => category.bios.length > 0);
  };

  const filteredCategories = getFilteredCategories();

  return (
    <div className="app">
      <header className="header">
        <div className="header-content">
          <div className="header-top">
            <h1 className="header-title">Instagram Bio</h1>
            <ThemeToggle isDark={isDarkTheme} onToggle={handleThemeToggle} />
          </div>
          <div className="search-section">
            <div className="search-bar">
              <input
                type="text"
                className="search-input"
                placeholder="Search for Instagram bios..."
                value={searchTerm}
                onChange={handleSearchChange}
                aria-label="Search Instagram bios"
              />
              <button className="search-btn" aria-label="Search">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="11" cy="11" r="8"></circle>
                  <path d="m21 21-4.35-4.35"></path>
                </svg>
              </button>
            </div>
            <KeywordsSection onKeywordClick={handleKeywordClick} activeKeyword={activeKeyword} />
          </div>
        </div>
      </header>

      <main className="main-content">
        {filteredCategories.length > 0 ? (
          filteredCategories.map((category) => (
            <section key={category.name} className="category-section">
              <h2>{category.name}</h2>
              <div className="bio-grid">
                {category.bios.map((bio, index) => (
                  <BioCard key={`${category.name}-${index}`} bio={bio} onCopy={handleCopy} />
                ))}
              </div>
            </section>
          ))
        ) : (
          <div className="category-section">
            <h2>No Results Found</h2>
            <p>Try searching for different keywords or clear your search to see all bios.</p>
          </div>
        )}
      </main>

      <Toast show={showToast} />
    </div>
  );
};

// Render the App
ReactDOM.render(<App />, document.getElementById('root'));